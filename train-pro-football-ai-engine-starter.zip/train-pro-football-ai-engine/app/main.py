from pathlib import Path
from uuid import uuid4

from fastapi import BackgroundTasks, Depends, FastAPI, File, Form, HTTPException, UploadFile

from app.config import get_settings
from app.schemas import AnalysisAccepted, AnalysisSummary
from app.security import require_api_key
from app.services.video import inspect_video, VideoReadError

app = FastAPI(title="Train Pro Football AI Engine", version="0.1.0")
JOBS: dict[str, dict] = {}
ALLOWED_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv"}


@app.get("/health")
def health():
    return {"status": "ok", "service": "train-pro-football-ai-engine", "version": "0.1.0"}


def process_job(job_id: str, path: Path, mode: str, player_id: str | None):
    job = JOBS[job_id]
    job["status"] = "processing"
    try:
        data = inspect_video(path, get_settings().frame_sample_fps)
        if data["model_error"]:
            quality = "not_evaluable"
            limitations = [data["model_error"]]
        elif data["frames_sampled"] < 10:
            quality = "unreliable"
            limitations = ["Too few sampled frames for a dependable analysis."]
        else:
            quality = "unreliable"
            limitations = [
                "This baseline detects and tracks people only; it does not yet identify the selected footballer.",
                "No pitch calibration, team classification, ball tracking, or validated football event metrics are implemented.",
            ]
        job.update({
            "status": "completed",
            "analysis_mode": mode,
            "player_id": player_id,
            "video_quality": quality,
            "frames_sampled": data["frames_sampled"],
            "duration_seconds": data["duration_seconds"],
            "people_detections": data["people_detections"],
            "unique_track_ids": data["unique_track_ids"],
            "limitations": limitations,
        })
    except VideoReadError as exc:
        job.update({"status": "failed", "error": str(exc)})
    except Exception as exc:
        job.update({"status": "failed", "error": f"Analysis failed: {type(exc).__name__}"})
    finally:
        path.unlink(missing_ok=True)


@app.post("/v1/analyze", response_model=AnalysisAccepted, dependencies=[Depends(require_api_key)])
async def analyze_video(
    background_tasks: BackgroundTasks,
    video: UploadFile = File(...),
    analysis_mode: str = Form("team"),
    player_id: str | None = Form(default=None),
):
    settings = get_settings()
    if analysis_mode not in {"team", "player"}:
        raise HTTPException(status_code=422, detail="analysis_mode must be team or player")
    if analysis_mode == "player" and not player_id:
        raise HTTPException(status_code=422, detail="player_id is required for player analysis")
    suffix = Path(video.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=415, detail="Supported formats: mp4, mov, avi, mkv")

    job_id = str(uuid4())
    destination = settings.upload_dir / f"{job_id}{suffix}"
    size = 0
    try:
        with destination.open("wb") as out:
            while chunk := await video.read(1024 * 1024):
                size += len(chunk)
                if size > settings.max_upload_mb * 1024 * 1024:
                    raise HTTPException(status_code=413, detail="Video exceeds upload limit")
                out.write(chunk)
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    finally:
        await video.close()

    JOBS[job_id] = {"job_id": job_id, "status": "queued"}
    background_tasks.add_task(process_job, job_id, destination, analysis_mode, player_id)
    return AnalysisAccepted(job_id=job_id, status="queued", message="Video accepted for analysis")


@app.get("/v1/jobs/{job_id}", response_model=AnalysisSummary, dependencies=[Depends(require_api_key)])
def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Analysis job not found")
    if job["status"] in {"queued", "processing"}:
        raise HTTPException(status_code=202, detail=job)
    if job["status"] == "failed":
        raise HTTPException(status_code=422, detail=job.get("error", "Analysis failed"))
    return job
