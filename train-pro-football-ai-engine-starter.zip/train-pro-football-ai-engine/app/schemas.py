from typing import Literal
from pydantic import BaseModel, Field


class AnalysisAccepted(BaseModel):
    job_id: str
    status: Literal["queued", "processing", "completed", "failed"]
    message: str


class AnalysisSummary(BaseModel):
    job_id: str
    status: Literal["completed", "failed"]
    analysis_mode: Literal["team", "player"]
    player_id: str | None = None
    video_quality: Literal["reliable", "unreliable", "not_evaluable"]
    frames_sampled: int = 0
    duration_seconds: float | None = None
    people_detections: int = 0
    unique_track_ids: int = 0
    limitations: list[str] = Field(default_factory=list)
