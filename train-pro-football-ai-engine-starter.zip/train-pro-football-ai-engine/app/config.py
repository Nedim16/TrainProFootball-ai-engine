from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Train Pro Football AI Engine"
    app_env: str = "development"
    api_key: str = "change-me"
    upload_dir: Path = Path("uploads")
    max_upload_mb: int = 500
    frame_sample_fps: float = 2.0
    yolo_model: str = "yolo11n.pt"
    enable_yolo: bool = False

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    return settings
