from app.config import get_settings


def run_person_tracking(cap, frame_count: int, frame_step: int):
    settings = get_settings()
    if not settings.enable_yolo:
        return 0, 0, set(), "YOLO tracking is disabled. Set ENABLE_YOLO=true to enable it."

    try:
        from ultralytics import YOLO
        model = YOLO(settings.yolo_model)
    except Exception as exc:
        return 0, 0, set(), f"Could not load YOLO model: {type(exc).__name__}"

    sampled = 0
    detections = 0
    track_ids: set[int] = set()
    frame_index = 0

    while frame_index < frame_count:
        cap.set(1, frame_index)  # cv2.CAP_PROP_POS_FRAMES
        ok, frame = cap.read()
        if not ok:
            break
        sampled += 1
        try:
            results = model.track(
                frame, persist=True, classes=[0], verbose=False, tracker="bytetrack.yaml"
            )
            for result in results:
                boxes = result.boxes
                if boxes is None:
                    continue
                detections += len(boxes)
                if boxes.id is not None:
                    track_ids.update(int(value) for value in boxes.id.cpu().tolist())
        except Exception as exc:
            return sampled, detections, track_ids, f"Tracking stopped: {type(exc).__name__}"
        frame_index += frame_step

    return sampled, detections, track_ids, None
