from pathlib import Path
import cv2


class VideoReadError(Exception):
    pass


def inspect_video(path: Path, sample_fps: float = 2.0) -> dict:
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise VideoReadError("Video could not be opened")

    fps = cap.get(cv2.CAP_PROP_FPS)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    duration = frame_count / fps if fps and fps > 0 else None
    if not fps or fps <= 0 or frame_count <= 0 or width <= 0 or height <= 0:
        cap.release()
        raise VideoReadError("Video metadata is invalid")

    step = max(1, round(fps / max(sample_fps, 0.1)))
    try:
        from app.services.tracking import run_person_tracking
        sampled, detections, track_ids, model_error = run_person_tracking(
            cap, frame_count, step
        )
    finally:
        cap.release()

    return {
        "duration_seconds": round(duration, 2) if duration is not None else None,
        "width": width,
        "height": height,
        "fps": round(fps, 2),
        "frames_sampled": sampled,
        "people_detections": detections,
        "unique_track_ids": len(track_ids),
        "model_error": model_error,
    }
