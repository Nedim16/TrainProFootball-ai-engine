# Train Pro Football AI Engine

Python/FastAPI service for the Train Pro Football application.

## Current status

This repository contains the first runnable API foundation:
- API-key protected video upload and analysis-job endpoints.
- Video metadata inspection and frame sampling with OpenCV.
- Optional person detection/tracking adapter using Ultralytics YOLO and ByteTrack.
- Explicit quality/limitations reporting; no unsupported football statistics are fabricated.
- Health endpoint and a basic test.

**This is a foundation, not a finished match-analysis product.** Player identity verification, team classification, ball tracking, pitch calibration, tactical/event recognition, validated physical metrics, persistent job storage, and Base44 webhook integration remain to be implemented and tested.

## Run locally

Python 3.11+ recommended.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open `/docs` for interactive API documentation and `/health` for the health check.

## Enable optional YOLO + ByteTrack

Install the optional computer-vision package:

```bash
pip install ultralytics
```

Set `ENABLE_YOLO=true` and optionally change `YOLO_MODEL` in `.env`. The first run may download model weights. YOLO is disabled by default.

## API

All analysis endpoints require the `X-API-Key` header matching `API_KEY` in the environment.

- `GET /health`
- `POST /v1/analyze` multipart fields: `video`, `analysis_mode=team|player`, optional `player_id`
- `GET /v1/jobs/{job_id}`

Example:

```bash
curl -X POST http://localhost:8000/v1/analyze \
  -H "X-API-Key: replace-with-a-long-random-secret" \
  -F "analysis_mode=team" \
  -F "video=@match.mp4"
```

## Security and deployment notes

- Set a long, unique `API_KEY`; never commit the real `.env`.
- Use HTTPS in deployment and restrict upload size.
- Jobs are currently held in process memory and are lost on restart; durable storage/queue is required before production.
- Uploaded videos are deleted after processing in this baseline. The product retention policy (six months or one month inactivity, whichever comes first) must be implemented in persistent cloud storage before production.
- Do not expose this service publicly until durable job storage, rate limiting, upload validation, observability, and deployment security are in place.
